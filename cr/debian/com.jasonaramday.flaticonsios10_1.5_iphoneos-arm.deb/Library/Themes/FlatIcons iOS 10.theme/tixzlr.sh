#!/bin/bash 

mkdir IconBundles
ls Bundles | grep -v "com.apple.springboard" | grep -v "com.apple.preferences-ui-framework" | while read m
do
cp Bundles/"$m"/"$(ls -s Bundles/"$m" | sort | tail -n2 | head -n1 | cut -d " " -f2-)" IconBundles/"$m"-large.png
done